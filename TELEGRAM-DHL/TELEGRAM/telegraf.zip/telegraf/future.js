module.exports = require('./lib/future')
