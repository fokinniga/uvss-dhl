/// <reference types="node" />
import { FmtString } from './format';
export declare const env: NodeJS.ProcessEnv;
export declare type Expand<T> = T extends object ? T extends infer O ? {
    [K in keyof O]: O[K];
} : never : T;
export declare type MaybeArray<T> = T | T[];
export declare type MaybePromise<T> = T | Promise<T>;
export declare type NonemptyReadonlyArray<T> = readonly [T, ...T[]];
declare type MaybeExtra<Extra> = (Extra & {
    caption?: string;
}) | undefined;
export declare function fmtCaption<Extra extends {
    caption?: string | FmtString;
} & Record<string, unknown>>(extra?: Extra): MaybeExtra<Extra>;
/** Construct a generic type guard */
export declare type Guard<X = unknown, Y extends X = X> = (x: X) => x is Y;
/** Extract the guarded type from a type guard, defaults to never. */
export declare type Guarded<F> = F extends (x: any) => x is infer T ? T : never;
export declare function deprecate(method: string, ignorable: string | undefined, use: string | undefined, see?: string): void;
export {};
//# sourceMappingURL=util.d.ts.map