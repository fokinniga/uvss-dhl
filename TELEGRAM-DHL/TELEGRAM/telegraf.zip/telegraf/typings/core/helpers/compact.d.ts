export declare function compactOptions<T extends {
    [key: string]: unknown;
}>(options?: T): T | undefined;
//# sourceMappingURL=compact.d.ts.map