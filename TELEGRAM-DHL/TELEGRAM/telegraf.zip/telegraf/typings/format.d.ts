import { User } from 'typegram';
import { FmtString } from './core/helpers/formatting';
export { FmtString };
export declare const fmt: (parts: string | TemplateStringsArray | string[], ...items: (FmtString | ({} | null | undefined))[]) => FmtString;
export declare const bold: (parts: string | TemplateStringsArray | string[], ...items: (FmtString | ({} | null | undefined))[]) => FmtString;
export declare const italic: (parts: string | TemplateStringsArray | string[], ...items: (FmtString | ({} | null | undefined))[]) => FmtString;
export declare const spoiler: (parts: string | TemplateStringsArray | string[], ...items: (FmtString | ({} | null | undefined))[]) => FmtString;
export declare const strikethrough: (parts: string | TemplateStringsArray | string[], ...items: (FmtString | ({} | null | undefined))[]) => FmtString;
export declare const underline: (parts: string | TemplateStringsArray | string[], ...items: (FmtString | ({} | null | undefined))[]) => FmtString;
export declare const code: (parts: string | TemplateStringsArray | string[], ...items: ({} | null | undefined)[]) => FmtString;
export declare const pre: (language: string) => (parts: string | TemplateStringsArray | string[], ...items: ({} | null | undefined)[]) => FmtString;
export declare const link: (content: string | FmtString, url: string) => FmtString;
export declare const mention: (name: string | FmtString, user: number | User) => FmtString;
//# sourceMappingURL=format.d.ts.map