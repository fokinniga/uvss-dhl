// Just an empty export to allow eslint to think there's an actual module here
// types.d.ts is the file we actually want to import
module.exports = {}
